# Sistem Informasi Keuangan
Aplikasi sistem informasi keuangan berbasis web ini dibaut bertujuan untuk mempermudah pengelolan keuangan baik itu pengeluaran maupun pemasukan. Aplikasi ini dilengkapi fitur login admin serta terdapat fitur laporan baik itu laporan pemasukan maupun laporan pengeluaran.

## Tampilan Aplikasi
![ss](img/ss1.png)
![ss](img/ss2.png)
![ss](img/ss3.png)
![ss](img/ss4.png)

## Login Aplikasi
|    Username    | Password |
|:--------------:|---------:|
| adam@gmail.com |   adam   |

## Fitur Aplikasi :
- Login Admin
- Dashboard
- Data Pendapatan
- Data Pengeluaran
- Data Karyawan
- Data Hutang
- Laporan
- Profile
- Logout
