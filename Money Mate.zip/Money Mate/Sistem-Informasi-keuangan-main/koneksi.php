<?php

$host = 'localhost';
$nama = 'root';
$pass = '';
$db = 'money_mate'; 

$koneksi = mysqli_connect($host, $nama,$pass, $db);
?>